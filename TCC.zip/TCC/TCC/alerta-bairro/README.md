# Alerta Bairro — projeto TCC

Plataforma comunitária para registrar e acompanhar problemas urbanos. O projeto usa React com Create React App (sem Vite), React Router, SCSS, Node.js, Express e MySQL.

## Funcionalidades incluídas

- Cadastro e login com senha criptografada (bcrypt) e autenticação JWT.
- Painel inicial com indicadores e relatos recentes.
- Cadastro de reclamações com categoria, endereço ou localização GPS, descrição e até 5 fotos.
- Pré-visualização e remoção das fotos antes do envio.
- Pesquisa por texto e filtro por status.
- Detalhes dos relatos, confirmação comunitária e atualização do status (pendente, em andamento ou resolvida).
- Central de atualizações com os status dos relatos criados pelo próprio morador.
- Perfil com edição de nome e bairro.
- Tela de mapa com diretório de endereços e abertura da localização no Google Maps.
- Layout responsivo para computador e celular.

## Importante sobre o MySQL

**Este projeto não cria, apaga nem altera tabelas.** Os arquivos SQL foram removidos do pacote porque o banco do projeto já está preparado no MySQL Workbench. Configure a conexão no arquivo `backend/.env` para apontar para o banco existente.

A API foi escrita para a estrutura de tabelas já usada no projeto:

- `usuarios`: `id`, `nome`, `email`, `senha_hash`, `bairro`, `criado_em`.
- `reclamacoes`: `id`, `usuario_id`, `titulo`, `categoria`, `descricao`, `endereco`, `status`, `criado_em`, `atualizado_em`.

Não execute scripts de criação de tabelas. Se os nomes das colunas no seu Workbench forem diferentes, a API precisará ser ajustada a esses nomes.

### Como as fotos são armazenadas

As imagens são gravadas em `backend/uploads/`. Para não exigir uma tabela adicional no MySQL, o vínculo entre o ID da reclamação e as imagens fica em `backend/data/report-images.json`; as confirmações da comunidade ficam em `backend/data/report-confirmations.json`. Esses arquivos JSON são criados automaticamente quando fotos são enviadas ou quando um morador confirma um relato. Não é necessário executar SQL para fotos. Faça backup da pasta `backend/uploads` junto com o banco se quiser preservar os anexos.

## Requisitos

- Node.js 18 ou superior
- MySQL em execução

## 1. Configurar o backend

Abra um terminal na pasta `backend` e instale as dependências:

```bash
npm install
```

Copie `.env.example` para `.env` e informe os dados da conexão que você já usa no MySQL Workbench:

```env
PORT=2020
DB_HOST=localhost
DB_PORT=3306
DB_USER=root
DB_PASSWORD=sua_senha_do_mysql
DB_NAME=alerta_bairro
JWT_SECRET=coloque-uma-chave-longa
FRONTEND_URL=http://localhost:3000
NODE_ENV=development
```

Use os mesmos host, usuário, senha e nome de banco que funcionam na sua instalação. Não compartilhe o `.env`.

Inicie a API:

```bash
npm run dev
```

Teste `http://localhost:2020/api/health`. A resposta deve conter `status: ok`.

## 2. Configurar o frontend

Em outro terminal, abra `frontend` e execute:

```bash
npm install
```

Copie `frontend/.env.example` para `frontend/.env` e mantenha a URL da API:

```env
REACT_APP_API_URL=http://localhost:2020/api
```

Inicie o site:

```bash
npm start
```

O React abre em `http://localhost:3000`. Crie uma conta pela tela de cadastro e depois entre com o mesmo e-mail e senha.

## Estrutura

```text
alerta-bairro-fullstack/
├── backend/
│   ├── src/config/
│   ├── src/controllers/
│   ├── src/middleware/
│   ├── src/routes/
│   ├── uploads/
│   ├── data/ (arquivos JSON locais, criados automaticamente)
│   └── src/app.js + src/server.js
├── frontend/
│   └── src/
│       ├── app/
│       ├── components/
│       ├── context/
│       ├── pages/
│       ├── services/
│       └── styles/
└── README.md
```

## Observação sobre o mapa

A tabela atual armazena endereço em texto, sem colunas separadas de latitude e longitude. Quando o morador permite, a localização GPS é registrada como coordenadas dentro do próprio campo de endereço; a tela abre essas coordenadas no Google Maps. Os demais relatos aparecem como uma lista pesquisável de endereços.
