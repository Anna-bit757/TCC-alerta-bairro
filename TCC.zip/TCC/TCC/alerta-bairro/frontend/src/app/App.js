import React from "react";
import { Navigate, Route, Routes } from "react-router-dom";
import { useAuth } from "../context/AuthContext";
import AppLayout from "../components/layout/AppLayout";
import Login from "../pages/login/Login";
import Cadastro from "../pages/cadastro/Cadastro";
import Inicio from "../pages/inicio/Inicio";
import Reclamacoes from "../pages/reclamacoes/Reclamacoes";
import Mapa from "../pages/mapa/Mapa";
import Perfil from "../pages/perfil/Perfil";

function Protected({ children }) {
  const { user, loading } = useAuth();
  if (loading) return <div className="loading-screen"><span className="spinner" />Carregando Alerta Bairro...</div>;
  return user ? children : <Navigate to="/login" replace />;
}

export default function App() {
  return (
    <Routes>
      <Route path="/login" element={<Login />} />
      <Route path="/cadastro" element={<Cadastro />} />
      <Route path="/" element={<Protected><AppLayout /></Protected>}>
        <Route index element={<Inicio />} />
        <Route path="reclamacoes" element={<Reclamacoes />} />
        <Route path="mapa" element={<Mapa />} />
        <Route path="perfil" element={<Perfil />} />
      </Route>
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
}
