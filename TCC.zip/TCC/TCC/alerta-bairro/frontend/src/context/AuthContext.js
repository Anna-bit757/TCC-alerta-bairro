import React, { createContext, useContext, useEffect, useMemo, useState } from "react";
import api from "../services/api";

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [user, setUser] = useState(() => {
    try { return JSON.parse(localStorage.getItem("alerta_bairro_user")) || null; }
    catch { return null; }
  });
  const [loading, setLoading] = useState(Boolean(localStorage.getItem("alerta_bairro_token")));

  useEffect(() => {
    const token = localStorage.getItem("alerta_bairro_token");
    if (!token) { setLoading(false); return; }
    api.get("/auth/me")
      .then(({ data }) => { setUser(data.user); localStorage.setItem("alerta_bairro_user", JSON.stringify(data.user)); })
      .catch(() => { setUser(null); localStorage.removeItem("alerta_bairro_user"); localStorage.removeItem("alerta_bairro_token"); })
      .finally(() => setLoading(false));
  }, []);

  const login = async (email, password) => {
    const { data } = await api.post("/auth/login", { email, password });
    localStorage.setItem("alerta_bairro_token", data.token);
    localStorage.setItem("alerta_bairro_user", JSON.stringify(data.user));
    setUser(data.user);
    return data.user;
  };

  const register = async (payload) => {
    const { data } = await api.post("/auth/register", payload);
    localStorage.setItem("alerta_bairro_token", data.token);
    localStorage.setItem("alerta_bairro_user", JSON.stringify(data.user));
    setUser(data.user);
    return data.user;
  };

  const logout = () => {
    localStorage.removeItem("alerta_bairro_token");
    localStorage.removeItem("alerta_bairro_user");
    setUser(null);
  };

  const value = useMemo(() => ({ user, loading, login, register, logout, setUser }), [user, loading]);
  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) throw new Error("useAuth deve ser usado dentro de AuthProvider");
  return context;
}
