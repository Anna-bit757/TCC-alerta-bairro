import React, { useState } from "react";
import { Outlet } from "react-router-dom";
import Sidebar from "./Sidebar";
import Topbar from "./Topbar";

export default function AppLayout() {
  const [menuOpen, setMenuOpen] = useState(false);
  return <div className="app-shell"><Sidebar open={menuOpen} onClose={() => setMenuOpen(false)} /><main className="main-area"><Topbar onMenu={() => setMenuOpen(true)} /><div className="page-content"><Outlet /></div><footer className="app-footer"><span>© {new Date().getFullYear()} Alerta Bairro</span><span>Feito para cuidar do lugar onde a gente vive <b>♥</b></span></footer></main></div>;
}
