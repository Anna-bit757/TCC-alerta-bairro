import React, { useState } from "react";
import { Link, useLocation } from "react-router-dom";
import Icon from "../ui/Icon";
import StatusBadge from "../reports/StatusBadge";
import { useAuth } from "../../context/AuthContext";
import api from "../../services/api";

const titles = {
  "/": ["Visão geral", "Acompanhe o que está acontecendo no seu bairro."],
  "/reclamacoes": ["Reclamações", "Registre, acompanhe e contribua com soluções."],
  "/mapa": ["Mapa do bairro", "Veja onde os problemas precisam de atenção."],
  "/perfil": ["Meu perfil", "Gerencie suas informações pessoais."],
};

export default function Topbar({ onMenu }) {
  const location = useLocation();
  const { user } = useAuth();
  const [notificationsOpen, setNotificationsOpen] = useState(false);
  const [notifications, setNotifications] = useState([]);
  const [notificationsLoading, setNotificationsLoading] = useState(false);
  const [notificationsError, setNotificationsError] = useState("");
  const [title, subtitle] = titles[location.pathname] || titles["/"];

  const toggleNotifications = async () => {
    const nextOpen = !notificationsOpen;
    setNotificationsOpen(nextOpen);
    if (!nextOpen) return;
    setNotificationsLoading(true);
    setNotificationsError("");
    try {
      const { data } = await api.get("/reports?mine=true&limit=8");
      setNotifications(data.reports || []);
    } catch {
      setNotificationsError("Não foi possível carregar as atualizações.");
    } finally {
      setNotificationsLoading(false);
    }
  };

  return (
    <header className="topbar">
      <button className="icon-button menu-button" onClick={onMenu} aria-label="Abrir menu"><Icon name="menu" /></button>
      <div className="topbar-heading"><h1>{title}</h1><p>{subtitle}</p></div>
      <div className="topbar-actions">
        <span className="topbar-date">{new Intl.DateTimeFormat("pt-BR", { weekday: "short", day: "2-digit", month: "short" }).format(new Date())}</span>
        <div className="notification-wrap">
          <button className="icon-button notification-button" title="Atualizações dos seus relatos" aria-label="Abrir atualizações" aria-expanded={notificationsOpen} onClick={toggleNotifications}>
            <Icon name="bell" />{notifications.some((report) => report.status !== "pendente") && <i />}
          </button>
          {notificationsOpen && (
            <section className="notification-panel" aria-label="Atualizações dos seus relatos">
              <div className="notification-heading"><strong>Seus relatos</strong><small>Atualizações recentes</small></div>
              {notificationsLoading ? <p className="notification-empty">Carregando...</p>
                : notificationsError ? <p className="notification-empty">{notificationsError}</p>
                : notifications.length ? notifications.map((report) => (
                  <Link className="notification-item" key={report.id} to="/reclamacoes" onClick={() => setNotificationsOpen(false)}>
                    <span><strong>{report.title}</strong><small>{new Date(report.updated_at || report.created_at).toLocaleDateString("pt-BR")}</small></span>
                    <StatusBadge status={report.status} />
                  </Link>
                )) : <p className="notification-empty">Você ainda não registrou reclamações.</p>}
              <Link className="notification-footer" to="/reclamacoes" onClick={() => setNotificationsOpen(false)}>Ver todos os relatos <Icon name="arrow" size={14} /></Link>
            </section>
          )}
        </div>
        <span className="topbar-divider" />
        <div className="topbar-user"><span className="avatar">{(user?.name || "U").slice(0, 1).toUpperCase()}</span><span><strong>{(user?.name || "Morador").split(" ")[0]}</strong><small>Morador</small></span></div>
      </div>
    </header>
  );
}
