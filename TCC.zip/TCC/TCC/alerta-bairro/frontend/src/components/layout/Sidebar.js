import React from "react";
import { NavLink, useNavigate } from "react-router-dom";
import { useAuth } from "../../context/AuthContext";
import Icon from "../ui/Icon";

const links = [
  { to: "/", label: "Visão geral", icon: "grid", end: true },
  { to: "/reclamacoes", label: "Reclamações", icon: "list" },
  { to: "/mapa", label: "Mapa do bairro", icon: "map" },
  { to: "/perfil", label: "Meu perfil", icon: "user" },
];

export default function Sidebar({ open, onClose }) {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const leave = () => { logout(); navigate("/login"); };
  return <>
    {open && <button className="sidebar-backdrop" onClick={onClose} aria-label="Fechar menu" />}
    <aside className={`sidebar ${open ? "sidebar--open" : ""}`}>
      <div className="brand"><span className="brand-mark"><Icon name="pin" size={25} /></span><span>Alerta<span className="brand-light">Bairro</span><small>COMUNIDADE EM AÇÃO</small></span></div>
      <div className="nav-label">MENU PRINCIPAL</div>
      <nav className="side-nav">
        {links.map(link => <NavLink key={link.to} to={link.to} end={link.end} onClick={onClose} className={({ isActive }) => `side-link ${isActive ? "active" : ""}`}><Icon name={link.icon} /><span>{link.label}</span>{link.to === "/reclamacoes" && <span className="nav-dot" />}</NavLink>)}
      </nav>
      <div className="sidebar-bottom">
        <div className="help-card"><span className="help-icon">?</span><strong>Precisa de ajuda?</strong><p>Juntos, deixamos o bairro melhor.</p><a href="mailto:suporte@alertabairro.local">Fale com a equipe <Icon name="arrow" size={14} /></a></div>
        <button className="user-mini" onClick={() => navigate("/perfil")}><span className="avatar">{(user?.name || "U").slice(0,1).toUpperCase()}</span><span className="user-mini-info"><strong>{user?.name || "Morador"}</strong><small>{user?.email || "Minha conta"}</small></span><Icon name="arrow" size={16} /></button>
        <button className="logout-link" onClick={leave}><Icon name="logout" size={18} /> Sair da conta</button>
      </div>
    </aside>
  </>;
}
