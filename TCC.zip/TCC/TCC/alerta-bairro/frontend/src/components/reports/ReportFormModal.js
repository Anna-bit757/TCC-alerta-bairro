import React, { useEffect, useRef, useState } from "react";
import Icon from "../ui/Icon";
import api from "../../services/api";
import "./ReportFormModal.scss";

const initial = { title: "", category: "limpeza", description: "", address: "" };
const MAX_IMAGES = 5;
const MAX_SIZE = 5 * 1024 * 1024;
const ACCEPTED = ["image/jpeg", "image/png", "image/webp"];

export default function ReportFormModal({ onClose, onCreate }) {
  const [form, setForm] = useState(initial);
  const [images, setImages] = useState([]);
  const [error, setError] = useState("");
  const [saving, setSaving] = useState(false);
  const [duplicateReports, setDuplicateReports] = useState([]);
  const [confirmedDuplicates, setConfirmedDuplicates] = useState(false);
  const [locating, setLocating] = useState(false);
  const inputRef = useRef(null);
  const previewUrls = useRef([]);

  useEffect(() => () => previewUrls.current.forEach((url) => URL.revokeObjectURL(url)), []);

  const change = (event) => setForm((current) => ({ ...current, [event.target.name]: event.target.value }));

  const useCurrentLocation = () => {
    if (!navigator.geolocation) {
      setError("Seu navegador não oferece suporte à localização.");
      return;
    }
    setLocating(true);
    setError("");
    navigator.geolocation.getCurrentPosition(
      ({ coords }) => {
        const latitude = coords.latitude.toFixed(6);
        const longitude = coords.longitude.toFixed(6);
        setForm((current) => ({ ...current, address: `GPS: ${latitude}, ${longitude}` }));
        setLocating(false);
      },
      () => {
        setError("Não foi possível obter sua localização. Confira a permissão do navegador ou digite o endereço.");
        setLocating(false);
      },
      { enableHighAccuracy: true, timeout: 10000, maximumAge: 60000 }
    );
  };

  const addImages = (event) => {
    const selected = Array.from(event.target.files || []);
    setError("");
    const available = MAX_IMAGES - images.length;
    if (selected.length > available) {
      setError(`Você pode anexar no máximo ${MAX_IMAGES} imagens.`);
      event.target.value = "";
      return;
    }
    const invalid = selected.find((file) => !ACCEPTED.includes(file.type) || file.size > MAX_SIZE);
    if (invalid) {
      setError("Use imagens JPG, PNG ou WEBP com até 5 MB cada.");
      event.target.value = "";
      return;
    }
    const additions = selected.map((file) => {
      const preview = URL.createObjectURL(file);
      previewUrls.current.push(preview);
      return { file, preview };
    });
    setImages((current) => [...current, ...additions]);
    event.target.value = "";
  };

  const removeImage = (index) => {
    setImages((current) => {
      const removed = current[index];
      if (removed) {
        URL.revokeObjectURL(removed.preview);
        previewUrls.current = previewUrls.current.filter((url) => url !== removed.preview);
      }
      return current.filter((_, itemIndex) => itemIndex !== index);
    });
  };

  const sendReport = async () => {
    const payload = new FormData();
    Object.entries(form).forEach(([key, value]) => payload.append(key, value));
    images.forEach(({ file }) => payload.append("images", file));
    setSaving(true);
    setError("");
    try {
      await onCreate(payload);
      onClose();
    } catch (err) {
      setError(err.response?.data?.message || "Não foi possível criar a reclamação.");
    } finally {
      setSaving(false);
    }
  };

  const submit = async (event) => {
    event.preventDefault();
    setError("");
    if (!form.title.trim() || !form.address.trim()) {
      setError("Preencha o título e o endereço.");
      return;
    }

    if (!confirmedDuplicates) {
      try {
        const { data } = await api.get("/reports");
        const normalize = (value) => String(value || "")
          .normalize("NFD")
          .replace(/[\u0300-\u036f]/g, "")
          .toLowerCase()
          .replace(/[^a-z0-9]+/g, " ")
          .trim();
        const title = normalize(form.title);
        const address = normalize(form.address);
        const similar = (data.reports || []).filter((report) => {
          const sameTitle = normalize(report.title) === title;
          const samePlaceAndCategory = normalize(report.address) === address
            && report.category === form.category;
          return sameTitle || samePlaceAndCategory;
        }).slice(0, 3);
        if (similar.length) {
          setDuplicateReports(similar);
          return;
        }
      } catch {
        // A falha na consulta de possíveis duplicados não impede o envio do relato.
      }
    }
    await sendReport();
  };

  return (
    <div className="modal-overlay" onMouseDown={(event) => { if (event.target === event.currentTarget && !saving) onClose(); }}>
      <section className="modal-card" role="dialog" aria-modal="true" aria-labelledby="new-report-title">
        <button type="button" className="modal-close icon-button" onClick={onClose} aria-label="Fechar" disabled={saving}><Icon name="close" /></button>
        <div className="modal-eyebrow">PARTICIPE DA MUDANÇA</div>
        <h2 id="new-report-title">Nova reclamação</h2>
        <p className="modal-description">Conte pra gente o que precisa melhorar no seu bairro.</p>

        <form onSubmit={submit} className="stack-form">
          <label className="field-label">Título<input className="form-input" name="title" value={form.title} onChange={change} placeholder="Ex.: Poste sem iluminação" required minLength="3" maxLength="120" /></label>
          <label className="field-label">Categoria<select className="form-input" name="category" value={form.category} onChange={change}><option value="limpeza">Limpeza urbana</option><option value="iluminacao">Iluminação</option><option value="via">Ruas e calçadas</option><option value="seguranca">Segurança</option><option value="outros">Outros</option></select></label>
          <label className="field-label">Endereço ou referência<input className="form-input" name="address" value={form.address} onChange={change} placeholder="Rua, número ou ponto de referência" required maxLength="255" /></label>
          <button type="button" className="location-button" onClick={useCurrentLocation} disabled={locating}>{locating ? "Obtendo localização..." : "Usar minha localização atual"}</button>
          <label className="field-label">Descrição<textarea className="form-input textarea" name="description" value={form.description} onChange={change} placeholder="Explique o que está acontecendo..." rows="4" maxLength="2000" /></label>

          <div className="field-label upload-field">
            <span>Fotos do problema <span className="upload-optional">(opcional)</span></span>
            <input ref={inputRef} className="upload-native-input" type="file" accept="image/jpeg,image/png,image/webp" multiple onChange={addImages} />
            <button type="button" className="upload-dropzone" onClick={() => inputRef.current?.click()} disabled={images.length >= MAX_IMAGES}>
              <span className="upload-icon"><Icon name="camera" size={21} /></span>
              <strong>Adicionar imagens</strong>
              <small>JPG, PNG ou WEBP · até 5 MB por foto</small>
              <small>{images.length}/{MAX_IMAGES} imagens selecionadas</small>
            </button>
            {images.length > 0 && (
              <div className="upload-preview-grid">
                {images.map((item, index) => (
                  <div className="upload-preview" key={`${item.file.name}-${index}`}>
                    <img src={item.preview} alt={`Pré-visualização ${index + 1}`} />
                    <button type="button" onClick={() => removeImage(index)} aria-label={`Remover imagem ${index + 1}`}><Icon name="close" size={14} /></button>
                    <span>{item.file.name}</span>
                  </div>
                ))}
              </div>
            )}
          </div>

          {duplicateReports.length > 0 && (
            <div className="duplicate-warning" role="status">
              <strong>Encontramos relatos que podem ser do mesmo problema.</strong>
              <ul>
                {duplicateReports.map((report) => <li key={report.id}>{report.title} — {report.address}</li>)}
              </ul>
              <p>Confira se algum deles já descreve essa situação antes de criar outro registro.</p>
              <button type="button" className="button button-secondary" onClick={() => { setConfirmedDuplicates(true); setDuplicateReports([]); sendReport(); }} disabled={saving}>É outro problema — continuar</button>
            </div>
          )}
          {error && <p className="form-error" role="alert">{error}</p>}
          <div className="modal-actions"><button type="button" className="button button-secondary" onClick={onClose} disabled={saving}>Cancelar</button><button className="button button-primary" disabled={saving}>{saving ? "Enviando..." : "Enviar reclamação"} <Icon name="arrow" size={16} /></button></div>
        </form>
      </section>
    </div>
  );
}
