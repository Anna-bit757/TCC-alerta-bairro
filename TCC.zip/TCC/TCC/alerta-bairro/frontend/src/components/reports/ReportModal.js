import React, { useState } from "react";
import Icon from "../ui/Icon";
import StatusBadge from "./StatusBadge";
import api from "../../services/api";

export default function ReportModal({ report, onClose, onUpdate }) {
  const [status, setStatus] = useState(report?.status || "pendente");
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");
  const [confirmations, setConfirmations] = useState(report?.confirmations || 0);
  const [confirmedByMe, setConfirmedByMe] = useState(Boolean(report?.confirmedByMe));
  const [confirming, setConfirming] = useState(false);
  if (!report) return null;
  const confirmReport = async () => { setConfirming(true); setError(""); try { const { data } = await api.post(`/reports/${report.id}/confirm`); setConfirmations(data.confirmations); setConfirmedByMe(data.confirmedByMe); } catch (err) { setError(err.response?.data?.message || "Não foi possível confirmar este relato."); } finally { setConfirming(false); } };
  const submit = async () => { setSaving(true); setError(""); try { await onUpdate(report.id, status); onClose(); } catch (err) { setError(err.response?.data?.message || "Não foi possível atualizar o status. Tente novamente."); } finally { setSaving(false); } };
  return <div className="modal-overlay" onMouseDown={(e) => { if (e.target === e.currentTarget) onClose(); }}><section className="modal-card" role="dialog" aria-modal="true" aria-labelledby="report-modal-title">
    <button className="modal-close icon-button" onClick={onClose} aria-label="Fechar"><Icon name="close" /></button>
    <div className="modal-eyebrow">DETALHES DA SOLICITAÇÃO</div><h2 id="report-modal-title">{report.title}</h2><StatusBadge status={report.status} />
    <p className="modal-description">{report.description || "Nenhuma descrição foi adicionada."}</p>
    <div className="community-confirmation"><div><strong>{confirmations} {confirmations === 1 ? "morador confirmou" : "moradores confirmaram"}</strong><small>Ajude a indicar que este problema também foi percebido pela comunidade.</small></div><button type="button" className={`button ${confirmedByMe ? "button-secondary" : "button-primary"}`} onClick={confirmReport} disabled={confirming || confirmedByMe}>{confirmedByMe ? "Relato confirmado" : confirming ? "Confirmando..." : "Eu também vi"}</button></div>
    {report.images?.length > 0 && <div className="report-photo-section"><strong>Fotos anexadas ({report.images.length})</strong><div className="report-photo-grid">{report.images.map((image) => <a key={image.id || image.url} href={new URL(image.url, api.defaults.baseURL).href} target="_blank" rel="noreferrer"><img src={new URL(image.url, api.defaults.baseURL).href} alt={image.name || "Foto da reclamação"} loading="lazy" /></a>)}</div></div>}
    <div className="detail-list"><div><small>Categoria</small><strong>{report.category}</strong></div><div><small>Local</small><strong>{report.address || "Não informado"}</strong></div><div><small>Aberta em</small><strong>{new Date(report.created_at).toLocaleString("pt-BR")}</strong></div></div>
    <label className="field-label" htmlFor="report-status">Atualizar status</label><select id="report-status" className="form-input" value={status} onChange={e => setStatus(e.target.value)}><option value="pendente">Pendente</option><option value="andamento">Em andamento</option><option value="resolvida">Resolvida</option></select>
    {error && <p className="form-error" role="alert">{error}</p>}
    <div className="modal-actions"><button className="button button-secondary" onClick={onClose}>Cancelar</button><button className="button button-primary" disabled={saving} onClick={submit}>{saving ? "Salvando..." : "Salvar alteração"}</button></div>
  </section></div>;
}
