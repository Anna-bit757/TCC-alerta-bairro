import React from "react";
import Icon from "../ui/Icon";
import StatusBadge from "./StatusBadge";

export default function ReportCard({ report, onClick }) {
  return <button className="report-card" onClick={() => onClick(report)}>
    <div className={`report-symbol symbol-${report.category || "outros"}`}><Icon name={report.category === "iluminacao" ? "bell" : report.category === "limpeza" ? "check" : report.category === "via" ? "map" : "pin"} size={20} /></div>
    <div className="report-main"><div className="report-title-row"><h3>{report.title}</h3><StatusBadge status={report.status} /></div><p>{report.description || "Sem descrição adicional."}</p><div className="report-meta"><span><Icon name="pin" size={14} />{report.address || "Endereço não informado"}</span><span><Icon name="clock" size={14} />{new Date(report.created_at).toLocaleDateString("pt-BR")}</span></div></div>
    <Icon name="arrow" size={18} className="report-arrow" />
  </button>;
}
