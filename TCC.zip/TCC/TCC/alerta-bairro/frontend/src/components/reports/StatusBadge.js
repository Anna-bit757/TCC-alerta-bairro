import React from "react";
const labels = { pendente: "Pendente", andamento: "Em andamento", resolvida: "Resolvida" };
export default function StatusBadge({ status }) { return <span className={`status-badge status-${status}`}>{labels[status] || status}</span>; }
