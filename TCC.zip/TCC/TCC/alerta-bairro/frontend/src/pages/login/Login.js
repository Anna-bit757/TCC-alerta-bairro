import React, { useState } from "react";
import { Link, Navigate, useNavigate } from "react-router-dom";
import { useAuth } from "../../context/AuthContext";
import Icon from "../../components/ui/Icon";
import "./Login.scss";

export default function Login() {
  const { user, login } = useAuth();
  const navigate = useNavigate();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  if (user) return <Navigate to="/" replace />;
  const submit = async e => { e.preventDefault(); setError(""); setLoading(true); try { await login(email, password); navigate("/"); } catch (err) { setError([err.response?.data?.message, err.response?.data?.detail].filter(Boolean).join(" — ") || (err.code === "ECONNABORTED" ? "A API demorou para responder. Confira se o backend está ligado." : "Não foi possível conectar à API. Confira se o backend está ligado e tente novamente.")); } finally { setLoading(false); } };
  return <main className="auth-page"><section className="auth-visual"><div className="auth-brand"><span className="brand-mark"><Icon name="pin" size={26}/></span><span>Alerta<span className="brand-light">Bairro</span></span></div><div className="visual-copy"><span className="eyebrow-light">SUA VOZ TRANSFORMA</span><h1>Um bairro melhor começa com <em>você.</em></h1><p>Registre problemas, acompanhe soluções e faça parte de uma comunidade que cuida do lugar onde vive.</p><div className="visual-stat"><span className="stat-icon"><Icon name="check" size={21}/></span><span><strong>Pequenas atitudes. Grandes mudanças.</strong><small>Conectando moradores a soluções.</small></span></div></div><div className="visual-decoration decoration-one"/><div className="visual-decoration decoration-two"/><small className="visual-footer">COMUNIDADE • CUIDADO • TRANSFORMAÇÃO</small></section>
    <section className="auth-form-side"><div className="auth-form-wrap"><span className="mobile-brand">ALERTA BAIRRO</span><span className="form-kicker">BEM-VINDO DE VOLTA</span><h2>Entre na sua conta</h2><p className="auth-subtitle">Acesse sua comunidade e acompanhe suas solicitações.</p><form onSubmit={submit} className="auth-form"><label className="field-label">E-mail<input className="form-input" type="email" autoComplete="email" value={email} onChange={e => setEmail(e.target.value)} placeholder="voce@exemplo.com" required /></label><label className="field-label">Senha<input className="form-input" type="password" autoComplete="current-password" value={password} onChange={e => setPassword(e.target.value)} placeholder="Digite sua senha" required /></label>{error && <p className="form-error">{error}</p>}<button className="button button-primary auth-submit" disabled={loading}>{loading ? "Entrando..." : "Entrar na plataforma"} <Icon name="arrow" size={18}/></button></form><p className="auth-switch">Ainda não tem uma conta? <Link to="/cadastro">Criar conta</Link></p><p className="auth-privacy">Ao continuar, você concorda em usar a plataforma de forma respeitosa e responsável.</p></div></section></main>;
}
