import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import api from "../../services/api";
import Icon from "../../components/ui/Icon";
import ReportCard from "../../components/reports/ReportCard";
import ReportModal from "../../components/reports/ReportModal";
import ReportFormModal from "../../components/reports/ReportFormModal";
import "./Inicio.scss";

export default function Inicio() {
  const [reports, setReports] = useState([]);
  const [stats, setStats] = useState({ total: 0, pendente: 0, andamento: 0, resolvida: 0 });
  const [selected, setSelected] = useState(null);
  const [creating, setCreating] = useState(false);
  const [error, setError] = useState("");
  const load = async () => {
    try { const [r, s] = await Promise.all([api.get("/reports?limit=5"), api.get("/reports/stats")]); setReports(r.data.reports); setStats(s.data.stats); setError(""); }
    catch { setError("Não foi possível carregar os dados. Verifique se a API e o banco estão ligados."); }
  };
  useEffect(() => { load(); }, []);
  const create = async payload => { await api.post("/reports", payload); await load(); };
  const update = async (id, status) => { await api.patch(`/reports/${id}/status`, { status }); await load(); };
  return <div className="dashboard-page">
    <section className="welcome-banner"><div className="welcome-copy"><span className="welcome-label"><i/> PAINEL DA COMUNIDADE</span><h2>Seu bairro, <em>nossa responsabilidade.</em></h2><p>Cada relato é um passo para uma cidade mais cuidadosa. Vamos fazer acontecer?</p><button className="button button-white" onClick={() => setCreating(true)}><Icon name="plus" size={18}/> Registrar problema</button></div><div className="welcome-art"><div className="art-circle circle-large"/><div className="art-circle circle-small"/><div className="art-pin"><Icon name="pin" size={42}/></div><span className="art-spark spark-a">✦</span><span className="art-spark spark-b">✦</span></div></section>
    {error && <div className="inline-error">{error}</div>}
    <section className="stats-grid">
      <article className="stat-card"><div className="stat-top"><span>Total de relatos</span><span className="stat-icon-box blue"><Icon name="list"/></span></div><strong>{stats.total}</strong><small>Registros da comunidade</small></article>
      <article className="stat-card"><div className="stat-top"><span>Aguardando atenção</span><span className="stat-icon-box orange"><Icon name="clock"/></span></div><strong>{stats.pendente}</strong><small>Precisam de encaminhamento</small></article>
      <article className="stat-card"><div className="stat-top"><span>Em andamento</span><span className="stat-icon-box purple"><Icon name="arrow"/></span></div><strong>{stats.andamento}</strong><small>Já estão sendo acompanhados</small></article>
      <article className="stat-card"><div className="stat-top"><span>Resolvidos</span><span className="stat-icon-box green"><Icon name="check"/></span></div><strong>{stats.resolvida}</strong><small>Problemas solucionados</small></article>
    </section>
    <section className="dashboard-lower"><div className="panel recent-panel"><div className="panel-heading"><div><h2>Relatos recentes</h2><p>Acompanhe as últimas solicitações do bairro.</p></div><Link to="/reclamacoes">Ver todos <Icon name="arrow" size={15}/></Link></div><div className="report-list">{reports.length ? reports.map(report => <ReportCard key={report.id} report={report} onClick={setSelected}/>) : <div className="empty-state"><span><Icon name="list" size={25}/></span><strong>Nenhuma reclamação por aqui</strong><p>Seja a primeira pessoa a registrar algo que precisa melhorar.</p><button className="button button-primary" onClick={() => setCreating(true)}>Criar primeiro relato</button></div>}</div></div>
      <aside className="panel community-panel"><div className="community-header"><span className="community-icon"><Icon name="pin" size={22}/></span><div><h2>Participação da comunidade</h2><p>O andamento dos registros feitos pelos moradores.</p></div></div><div className="community-progress"><div className="progress-heading"><span>Relatos resolvidos</span><strong>{stats.total ? Math.round((stats.resolvida / stats.total) * 100) : 0}%</strong></div><div className="progress-track"><span style={{ width: `${stats.total ? (stats.resolvida / stats.total) * 100 : 0}%` }}/></div><div className="progress-foot"><span>{stats.resolvida} de {stats.total} registros</span><span>{stats.pendente} aguardando</span></div></div><div className="community-note"><span className="note-icon"><Icon name="check" size={17}/></span><p><strong>Um relato bem feito ajuda.</strong>Inclua um endereço fácil de localizar e descreva o problema com clareza.</p></div><Link className="community-map-link" to="/mapa">Consultar locais dos relatos <Icon name="arrow" size={16}/></Link></aside></section>
    {selected && <ReportModal report={selected} onClose={() => setSelected(null)} onUpdate={update}/>}
    {creating && <ReportFormModal onClose={() => setCreating(false)} onCreate={create}/>}
  </div>;
}
