import React, { useState } from "react";
import { Link, Navigate, useNavigate } from "react-router-dom";
import { useAuth } from "../../context/AuthContext";
import Icon from "../../components/ui/Icon";
import "./Cadastro.scss";

export default function Cadastro() {
  const { user, register } = useAuth();
  const navigate = useNavigate();
  const [form, setForm] = useState({ name: "", email: "", password: "", neighborhood: "" });
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  if (user) return <Navigate to="/" replace />;
  const change = e => setForm({ ...form, [e.target.name]: e.target.value });
  const submit = async e => { e.preventDefault(); setError(""); if (form.password.length < 8) { setError("A senha precisa ter pelo menos 8 caracteres."); return; } setLoading(true); try { await register(form); navigate("/"); } catch (err) { setError(err.response?.data?.message || "Não foi possível criar a conta."); } finally { setLoading(false); } };
  return <main className="register-page"><div className="register-top"><Link to="/login" className="register-brand"><span className="brand-mark"><Icon name="pin" size={23}/></span>Alerta<span>Bairro</span></Link><span>Já tem uma conta? <Link to="/login">Entrar</Link></span></div><section className="register-card"><div className="register-icon"><Icon name="user" size={25}/></div><span className="form-kicker">FAÇA PARTE DA MUDANÇA</span><h1>Crie sua conta</h1><p>Junte-se aos moradores que estão construindo um bairro melhor.</p><form className="auth-form" onSubmit={submit}><label className="field-label">Nome completo<input className="form-input" name="name" value={form.name} onChange={change} placeholder="Como podemos te chamar?" required minLength="2" maxLength="100"/></label><label className="field-label">E-mail<input className="form-input" type="email" name="email" value={form.email} onChange={change} placeholder="voce@exemplo.com" required/></label><label className="field-label">Bairro (opcional)<input className="form-input" name="neighborhood" value={form.neighborhood} onChange={change} placeholder="Onde você mora?"/></label><label className="field-label">Senha<input className="form-input" type="password" name="password" value={form.password} onChange={change} placeholder="No mínimo 8 caracteres" required minLength="8" autoComplete="new-password"/></label>{error && <p className="form-error">{error}</p>}<button className="button button-primary auth-submit" disabled={loading}>{loading ? "Criando conta..." : "Criar minha conta"} <Icon name="arrow" size={18}/></button></form><p className="auth-privacy">Seus dados são usados para manter sua conta e suas solicitações.</p></section></main>;
}
