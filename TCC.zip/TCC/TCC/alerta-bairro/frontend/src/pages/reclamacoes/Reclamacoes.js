import React, { useEffect, useMemo, useState } from "react";
import api from "../../services/api";
import Icon from "../../components/ui/Icon";
import ReportCard from "../../components/reports/ReportCard";
import ReportModal from "../../components/reports/ReportModal";
import ReportFormModal from "../../components/reports/ReportFormModal";
import "./Reclamacoes.scss";

export default function Reclamacoes() {
  const [reports, setReports] = useState([]);
  const [query, setQuery] = useState("");
  const [status, setStatus] = useState("todos");
  const [selected, setSelected] = useState(null);
  const [creating, setCreating] = useState(false);
  const [error, setError] = useState("");
  const load = async () => { try { const { data } = await api.get("/reports"); setReports(data.reports); setError(""); } catch { setError("Não foi possível carregar as reclamações. Confira se a API está ativa."); } };
  useEffect(() => { load(); }, []);
  const filtered = useMemo(() => reports.filter(r => (status === "todos" || r.status === status) && `${r.title} ${r.description || ""} ${r.address || ""}`.toLowerCase().includes(query.toLowerCase())), [reports, status, query]);
  const create = async payload => { await api.post("/reports", payload); await load(); };
  const update = async (id, nextStatus) => { await api.patch(`/reports/${id}/status`, { status: nextStatus }); await load(); };
  return <div className="complaints-page"><section className="page-intro"><div><span className="section-kicker">TRANSPARÊNCIA E PARTICIPAÇÃO</span><h2>Todas as reclamações</h2><p>Encontre um relato, acompanhe o andamento ou registre um novo problema.</p></div><button className="button button-primary" onClick={() => setCreating(true)}><Icon name="plus" size={17}/> Nova reclamação</button></section>
    {error && <div className="inline-error">{error}</div>}
    <section className="filter-panel"><div className="search-field"><Icon name="search" size={18}/><input value={query} onChange={e => setQuery(e.target.value)} placeholder="Buscar por título, endereço ou descrição..." aria-label="Buscar reclamações"/>{query && <button onClick={() => setQuery("")} aria-label="Limpar busca"><Icon name="close" size={15}/></button>}</div><label className="filter-select-label"><span>Status</span><select value={status} onChange={e => setStatus(e.target.value)}><option value="todos">Todos os status</option><option value="pendente">Pendente</option><option value="andamento">Em andamento</option><option value="resolvida">Resolvida</option></select></label><span className="results-count">{filtered.length} {filtered.length === 1 ? "resultado" : "resultados"}</span></section>
    <section className="complaints-list panel">{filtered.length ? filtered.map(r => <ReportCard key={r.id} report={r} onClick={setSelected}/>) : <div className="empty-state"><span><Icon name="search" size={25}/></span><strong>Nenhum resultado encontrado</strong><p>Tente mudar o termo de busca ou o filtro selecionado.</p></div>}</section>
    {selected && <ReportModal report={selected} onClose={() => setSelected(null)} onUpdate={update}/>}
    {creating && <ReportFormModal onClose={() => setCreating(false)} onCreate={create}/>}
  </div>;
}
