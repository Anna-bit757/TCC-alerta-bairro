import React, { useEffect, useState } from "react";
import api from "../../services/api";
import Icon from "../../components/ui/Icon";
import StatusBadge from "../../components/reports/StatusBadge";
import "./Mapa.scss";

export default function Mapa() {
  const [reports, setReports] = useState([]);
  const [selected, setSelected] = useState(null);
  const [query, setQuery] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let active = true;
    api.get("/reports")
      .then(({ data }) => { if (active) setReports(data.reports || []); })
      .catch(() => { if (active) setError("Não foi possível carregar os relatos. Confira se a API está ativa."); })
      .finally(() => { if (active) setLoading(false); });
    return () => { active = false; };
  }, []);

  const filtered = reports.filter((report) =>
    `${report.title} ${report.address || ""} ${report.category || ""}`.toLowerCase().includes(query.toLowerCase())
  );
  const openMap = (address) => {
    const coordinates = String(address || "").match(/^GPS:\s*(-?\d+(?:\.\d+)?),\s*(-?\d+(?:\.\d+)?)/i);
    const query = coordinates ? `${coordinates[1]},${coordinates[2]}` : address;
    return `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(query)}`;
  };

  return (
    <div className="map-page">
      <section className="page-intro">
        <div><span className="section-kicker">LOCALIZAÇÃO DOS REGISTROS</span><h2>Mapa do bairro</h2><p>Encontre o endereço de cada problema e abra a localização no serviço de mapas.</p></div>
        <span className="map-count"><Icon name="pin" size={16}/>{reports.length} {reports.length === 1 ? "relato" : "relatos"}</span>
      </section>
      {error && <div className="inline-error" role="alert">{error}</div>}
      <section className="map-directory-layout">
        <div className="map-directory panel">
          <div className="map-directory-heading"><div><h3>Locais registrados</h3><p>Pesquise pelo título, categoria ou endereço.</p></div><span className="directory-total">{filtered.length}</span></div>
          <label className="map-search"><Icon name="search" size={18}/><input value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Buscar local ou problema..." aria-label="Buscar relatos"/></label>
          {loading ? <div className="map-empty">Carregando relatos...</div> : filtered.length ? (
            <div className="map-directory-list">
              {filtered.map((report) => (
                <article className={`map-directory-item ${selected?.id === report.id ? "selected" : ""}`} key={report.id}>
                  <button className="map-directory-select" onClick={() => setSelected(report)}>
                    <span className="map-report-pin"><Icon name="pin" size={17}/></span>
                    <span className="map-directory-copy"><strong>{report.title}</strong><small>{report.address || "Endereço não informado"}</small><span className="map-directory-meta"><StatusBadge status={report.status}/><small>{new Date(report.created_at).toLocaleDateString("pt-BR")}</small></span></span>
                  </button>
                  {report.address && <a className="map-open-link" href={openMap(report.address)} target="_blank" rel="noreferrer" aria-label={`Abrir ${report.address} no Google Maps`}><Icon name="arrow" size={17}/></a>}
                </article>
              ))}
            </div>
          ) : <div className="map-empty"><Icon name="search" size={24}/><strong>Nenhum relato encontrado</strong><span>{reports.length ? "Tente outro termo de busca." : "Quando um morador registrar um problema, ele aparecerá aqui."}</span></div>}
        </div>
        <aside className="map-info panel">
          <div className="map-info-icon"><Icon name="map" size={25}/></div>
          <span className="section-kicker">CONSULTA DE ENDEREÇO</span>
          <h3>{selected ? selected.title : "Localização dos problemas"}</h3>
          <p>{selected ? (selected.address || "Este relato ainda não possui endereço cadastrado.") : "Selecione um registro na lista para consultar o endereço e abrir a localização em um mapa."}</p>
          {selected && <div className="map-info-status"><span>Status</span><StatusBadge status={selected.status}/></div>}
          {selected?.address ? <a className="button button-primary map-info-button" href={openMap(selected.address)} target="_blank" rel="noreferrer">Abrir no Google Maps <Icon name="arrow" size={16}/></a> : <div className="map-info-note"><Icon name="info" size={16}/><span>O sistema registra endereços em texto. Coordenadas GPS e marcadores exatos ainda não fazem parte desta versão.</span></div>}
        </aside>
      </section>
    </div>
  );
}
