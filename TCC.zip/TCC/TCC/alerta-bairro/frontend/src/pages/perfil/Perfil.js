import React, { useEffect, useState } from "react";
import { useAuth } from "../../context/AuthContext";
import api from "../../services/api";
import Icon from "../../components/ui/Icon";
import "./Perfil.scss";

export default function Perfil() {
  const { user, setUser } = useAuth();
  const [form, setForm] = useState({ name: user?.name || "", neighborhood: user?.neighborhood || "" });
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");
  const [saving, setSaving] = useState(false);
  useEffect(() => setForm({ name: user?.name || "", neighborhood: user?.neighborhood || "" }), [user]);
  const submit = async e => { e.preventDefault(); setMessage(""); setError(""); setSaving(true); try { const { data } = await api.patch("/users/me", form); setUser(data.user); localStorage.setItem("alerta_bairro_user", JSON.stringify(data.user)); setMessage("Seus dados foram atualizados."); } catch (err) { setError(err.response?.data?.message || "Não foi possível atualizar o perfil."); } finally { setSaving(false); } };
  return <div className="profile-page"><section className="page-intro"><div><span className="section-kicker">SUA CONTA</span><h2>Meu perfil</h2><p>Mantenha seus dados atualizados para participar da comunidade.</p></div></section>
    <section className="profile-layout"><aside className="profile-summary panel"><div className="profile-avatar">{(user?.name || "U").slice(0,1).toUpperCase()}</div><h3>{user?.name}</h3><p>{user?.email}</p><span className="member-pill"><Icon name="check" size={13}/> Morador cadastrado</span><div className="profile-summary-note"><Icon name="pin" size={17}/><span><strong>Seu bairro importa</strong><small>Participe, registre e acompanhe melhorias na sua região.</small></span></div></aside>
      <section className="profile-form-panel panel"><div className="profile-panel-heading"><span className="profile-heading-icon"><Icon name="user" size={20}/></span><div><h3>Informações pessoais</h3><p>Essas informações identificam sua conta.</p></div></div><form onSubmit={submit} className="profile-form"><label className="field-label">Nome completo<input className="form-input" value={form.name} onChange={e => setForm({...form,name:e.target.value})} required minLength="2" maxLength="100"/></label><label className="field-label">E-mail<input className="form-input readonly-input" value={user?.email || ""} readOnly/><small className="field-help">O e-mail não pode ser alterado nesta versão.</small></label><label className="field-label">Bairro<input className="form-input" value={form.neighborhood} onChange={e => setForm({...form,neighborhood:e.target.value})} placeholder="Seu bairro"/></label>{message && <p className="form-success">{message}</p>}{error && <p className="form-error">{error}</p>}<div className="profile-actions"><button className="button button-primary" disabled={saving}>{saving ? "Salvando..." : "Salvar alterações"} <Icon name="check" size={16}/></button></div></form></section></section>
  </div>;
}
