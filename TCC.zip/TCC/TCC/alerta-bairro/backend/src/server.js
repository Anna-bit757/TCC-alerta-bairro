require("dotenv").config();
const app = require("./app");
const db = require("./config/database");
const port = Number(process.env.PORT || 2020);

async function start() {
  try {
    await db.query("SELECT 1");
    console.log("Conexão com MySQL estabelecida.");
  } catch (error) {
    console.error("Não foi possível conectar ao MySQL. Confira DB_HOST, DB_PORT, DB_USER, DB_PASSWORD e DB_NAME no arquivo .env.");
    console.error(error.message);
    process.exit(1);
  }
  app.listen(port, () => console.log(`Alerta Bairro API rodando em http://localhost:${port}`));
}
start();
