const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const db = require("../config/database");

function publicUser(row) {
  return {
    id: row.id,
    name: row.nome,
    email: row.email,
    neighborhood: row.bairro || "",
    createdAt: row.criado_em || null,
  };
}

function createToken(user) {
  return jwt.sign(
    { sub: user.id },
    process.env.JWT_SECRET || "desenvolvimento-troque-esta-chave",
    { expiresIn: "7d" }
  );
}

async function register(req, res, next) {
  try {
    const name = String(req.body.name || "").trim();
    const email = String(req.body.email || "").trim().toLowerCase();
    const password = String(req.body.password || "");
    const neighborhood = String(req.body.neighborhood || "").trim();

    if (name.length < 2 || name.length > 100) return res.status(400).json({ message: "Informe um nome válido." });
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return res.status(400).json({ message: "Informe um e-mail válido." });
    if (password.length < 8) return res.status(400).json({ message: "A senha precisa ter pelo menos 8 caracteres." });
    if (neighborhood.length > 120) return res.status(400).json({ message: "O bairro deve ter até 120 caracteres." });

    const [existing] = await db.execute("SELECT id FROM usuarios WHERE email = ? LIMIT 1", [email]);
    if (existing.length) return res.status(409).json({ message: "Já existe uma conta com esse e-mail." });

    const hash = await bcrypt.hash(password, 12);
    const [result] = await db.execute(
      "INSERT INTO usuarios (nome, email, senha_hash, bairro) VALUES (?, ?, ?, ?)",
      [name, email, hash, neighborhood]
    );
    const [rows] = await db.execute(
      "SELECT id, nome, email, bairro, criado_em FROM usuarios WHERE id = ? LIMIT 1",
      [result.insertId]
    );
    if (!rows.length) return res.status(500).json({ message: "A conta foi criada, mas não foi possível carregar os dados do usuário." });
    const user = publicUser(rows[0]);
    return res.status(201).json({ token: createToken(user), user });
  } catch (error) {
    return next(error);
  }
}

async function login(req, res, next) {
  try {
    const email = String(req.body.email || "").trim().toLowerCase();
    const password = String(req.body.password || "");
    if (!email || !password) return res.status(400).json({ message: "Informe seu e-mail e sua senha." });

    const [rows] = await db.execute(
      "SELECT id, nome, email, senha_hash, bairro, criado_em FROM usuarios WHERE email = ? LIMIT 1",
      [email]
    );
    if (!rows.length) return res.status(401).json({ message: "E-mail ou senha incorretos." });

    const row = rows[0];
    const passwordMatches = typeof row.senha_hash === "string" && row.senha_hash.length > 0
      ? await bcrypt.compare(password, row.senha_hash)
      : false;
    if (!passwordMatches) return res.status(401).json({ message: "E-mail ou senha incorretos." });

    const user = publicUser(row);
    return res.json({ token: createToken(user), user });
  } catch (error) {
    return next(error);
  }
}

async function me(req, res) {
  return res.json({ user: publicUser(req.user) });
}

module.exports = { register, login, me };
