const db = require("../config/database");

async function updateMe(req, res, next) {
  try {
    const name = String(req.body.name || "").trim();
    const neighborhood = String(req.body.neighborhood || "").trim();
    if (name.length < 2 || name.length > 100) return res.status(400).json({ message: "Informe um nome entre 2 e 100 caracteres." });
    if (neighborhood.length > 120) return res.status(400).json({ message: "O bairro deve ter até 120 caracteres." });
    await db.execute("UPDATE usuarios SET nome = ?, bairro = ? WHERE id = ?", [name, neighborhood, req.user.id]);
    const [rows] = await db.execute("SELECT id, nome, email, bairro, criado_em FROM usuarios WHERE id = ?", [req.user.id]);
    const row = rows[0];
    return res.json({ user: { id: row.id, name: row.nome, email: row.email, neighborhood: row.bairro || "", createdAt: row.criado_em } });
  } catch (error) { next(error); }
}

module.exports = { updateMe };
