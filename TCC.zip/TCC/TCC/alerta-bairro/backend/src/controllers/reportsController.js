const db = require("../config/database");
const fs = require("fs/promises");
const path = require("path");
const { uploadDir } = require("../middleware/upload");

const validStatuses = ["pendente", "andamento", "resolvida"];
const validCategories = ["limpeza", "iluminacao", "via", "seguranca", "outros"];
const dataDir = path.join(__dirname, "../../data");
const imageIndexPath = path.join(dataDir, "report-images.json");
const confirmationIndexPath = path.join(dataDir, "report-confirmations.json");
let imageWriteQueue = Promise.resolve();

async function readImageIndex() {
  try {
    const content = await fs.readFile(imageIndexPath, "utf8");
    const parsed = JSON.parse(content);
    return parsed && typeof parsed === "object" && !Array.isArray(parsed) ? parsed : {};
  } catch (error) {
    if (error.code === "ENOENT") return {};
    throw error;
  }
}

async function updateImageIndex(updater) {
  const operation = imageWriteQueue.then(async () => {
    await fs.mkdir(dataDir, { recursive: true });
    const index = await readImageIndex();
    const next = updater(index) || index;
    const temporaryPath = `${imageIndexPath}.tmp`;
    await fs.writeFile(temporaryPath, JSON.stringify(next, null, 2), "utf8");
    await fs.rename(temporaryPath, imageIndexPath);
  });
  imageWriteQueue = operation.catch(() => {});
  return operation;
}

async function removeUploadedFiles(files = []) {
  await Promise.all(files.map((file) => fs.unlink(path.join(uploadDir, file.filename)).catch(() => {})));
}

function mapReport(row, images = [], confirmations = [], userId = null) {
  return {
    id: row.id,
    title: row.titulo,
    category: row.categoria,
    description: row.descricao || "",
    address: row.endereco,
    status: row.status,
    created_at: row.criado_em,
    updated_at: row.atualizado_em,
    author: row.autor || "",
    images,
    confirmations: confirmations.length,
    confirmedByMe: userId !== null && confirmations.includes(String(userId)),
  };
}

async function attachImages(rows, userId = null) {
  if (!rows.length) return [];
  const [imageIndex, confirmationIndex] = await Promise.all([
    readImageIndex(),
    (async () => {
      try {
        const content = await fs.readFile(confirmationIndexPath, "utf8");
        const parsed = JSON.parse(content);
        return parsed && typeof parsed === "object" && !Array.isArray(parsed) ? parsed : {};
      } catch (error) {
        if (error.code === "ENOENT") return {};
        throw error;
      }
    })(),
  ]);
  return rows.map((row) => mapReport(
    row,
    Array.isArray(imageIndex[String(row.id)]) ? imageIndex[String(row.id)] : [],
    Array.isArray(confirmationIndex[String(row.id)]) ? confirmationIndex[String(row.id)] : [],
    userId
  ));
}

async function list(req, res, next) {
  try {
    const status = String(req.query.status || "");
    const limit = Math.min(Math.max(Number(req.query.limit) || 100, 1), 100);
    const where = [];
    const params = [];
    if (req.query.mine === "true") {
      where.push("r.usuario_id = ?");
      params.push(req.user.id);
    }
    if (validStatuses.includes(status)) {
      where.push("r.status = ?");
      params.push(status);
    }
    const sql = `SELECT r.*, u.nome AS autor FROM reclamacoes r JOIN usuarios u ON u.id = r.usuario_id ${where.length ? "WHERE " + where.join(" AND ") : ""} ORDER BY r.criado_em DESC LIMIT ?`;
    params.push(limit);
    const [rows] = await db.execute(sql, params);
    return res.json({ reports: await attachImages(rows, req.user.id) });
  } catch (error) {
    return next(error);
  }
}

async function stats(req, res, next) {
  try {
    const [rows] = await db.execute("SELECT COUNT(*) AS total, SUM(status = 'pendente') AS pendente, SUM(status = 'andamento') AS andamento, SUM(status = 'resolvida') AS resolvida FROM reclamacoes");
    const row = rows[0] || {};
    return res.json({
      stats: {
        total: Number(row.total || 0),
        pendente: Number(row.pendente || 0),
        andamento: Number(row.andamento || 0),
        resolvida: Number(row.resolvida || 0),
      },
    });
  } catch (error) {
    return next(error);
  }
}

async function create(req, res, next) {
  const files = req.files || [];
  let connection;
  try {
    const title = String(req.body.title || "").trim();
    const category = String(req.body.category || "outros");
    const description = String(req.body.description || "").trim();
    const address = String(req.body.address || "").trim();

    if (title.length < 3 || title.length > 120) {
      await removeUploadedFiles(files);
      return res.status(400).json({ message: "O título deve ter entre 3 e 120 caracteres." });
    }
    if (!validCategories.includes(category)) {
      await removeUploadedFiles(files);
      return res.status(400).json({ message: "Categoria inválida." });
    }
    if (!address || address.length > 255) {
      await removeUploadedFiles(files);
      return res.status(400).json({ message: "Informe um endereço ou ponto de referência." });
    }
    if (description.length > 2000) {
      await removeUploadedFiles(files);
      return res.status(400).json({ message: "A descrição deve ter até 2000 caracteres." });
    }

    connection = await db.getConnection();
    await connection.beginTransaction();
    const [result] = await connection.execute(
      "INSERT INTO reclamacoes (usuario_id, titulo, categoria, descricao, endereco) VALUES (?, ?, ?, ?, ?)",
      [req.user.id, title, category, description, address]
    );
    await connection.commit();

    const images = files.map((file) => ({
      id: file.filename,
      url: `/uploads/${file.filename}`,
      name: file.originalname.slice(0, 255),
    }));
    if (images.length) {
      await updateImageIndex((index) => {
        index[String(result.insertId)] = images;
        return index;
      });
    }

    const [rows] = await db.execute(
      "SELECT r.*, u.nome AS autor FROM reclamacoes r JOIN usuarios u ON u.id = r.usuario_id WHERE r.id = ?",
      [result.insertId]
    );
    return res.status(201).json({ report: mapReport(rows[0], images, [], req.user.id) });
  } catch (error) {
    if (connection) await connection.rollback().catch(() => {});
    await removeUploadedFiles(files);
    return next(error);
  } finally {
    if (connection) connection.release();
  }
}

async function updateStatus(req, res, next) {
  try {
    const id = Number(req.params.id);
    const status = String(req.body.status || "");
    if (!Number.isInteger(id) || id < 1) return res.status(400).json({ message: "Identificador inválido." });
    if (!validStatuses.includes(status)) return res.status(400).json({ message: "Status inválido." });
    const [result] = await db.execute("UPDATE reclamacoes SET status = ? WHERE id = ?", [status, id]);
    if (!result.affectedRows) return res.status(404).json({ message: "Reclamação não encontrada." });
    const [rows] = await db.execute("SELECT r.*, u.nome AS autor FROM reclamacoes r JOIN usuarios u ON u.id = r.usuario_id WHERE r.id = ?", [id]);
    const reports = await attachImages(rows, req.user.id);
    return res.json({ report: reports[0] });
  } catch (error) {
    return next(error);
  }
}

async function confirm(req, res, next) {
  try {
    const id = Number(req.params.id);
    if (!Number.isInteger(id) || id < 1) return res.status(400).json({ message: "Identificador inválido." });
    const [rows] = await db.execute("SELECT id FROM reclamacoes WHERE id = ? LIMIT 1", [id]);
    if (!rows.length) return res.status(404).json({ message: "Reclamação não encontrada." });

    const operation = imageWriteQueue.then(async () => {
      await fs.mkdir(dataDir, { recursive: true });
      let index = {};
      try {
        index = JSON.parse(await fs.readFile(confirmationIndexPath, "utf8"));
      } catch (error) {
        if (error.code !== "ENOENT") throw error;
      }
      if (!index || typeof index !== "object" || Array.isArray(index)) index = {};
      const key = String(id);
      const people = Array.isArray(index[key]) ? index[key].map(String) : [];
      const userId = String(req.user.id);
      if (!people.includes(userId)) people.push(userId);
      index[key] = people;
      const temporaryPath = `${confirmationIndexPath}.tmp`;
      await fs.writeFile(temporaryPath, JSON.stringify(index, null, 2), "utf8");
      await fs.rename(temporaryPath, confirmationIndexPath);
      return people;
    });
    imageWriteQueue = operation.catch(() => {});
    const people = await operation;
    return res.json({ confirmations: people.length, confirmedByMe: people.includes(String(req.user.id)) });
  } catch (error) {
    return next(error);
  }
}

module.exports = { list, stats, create, updateStatus, confirm };
