const jwt = require("jsonwebtoken");
const db = require("../config/database");

async function authRequired(req, res, next) {
  const header = req.headers.authorization || "";
  const token = header.startsWith("Bearer ") ? header.slice(7) : null;
  if (!token) return res.status(401).json({ message: "Faça login para continuar." });
  try {
    const payload = jwt.verify(token, process.env.JWT_SECRET || "desenvolvimento-troque-esta-chave");
    const [rows] = await db.execute("SELECT id, nome, email, bairro, criado_em FROM usuarios WHERE id = ?", [payload.sub]);
    if (!rows.length) return res.status(401).json({ message: "Sessão inválida. Entre novamente." });
    req.user = rows[0];
    next();
  } catch (error) {
    return res.status(401).json({ message: "Sessão expirada ou inválida." });
  }
}

module.exports = { authRequired };
