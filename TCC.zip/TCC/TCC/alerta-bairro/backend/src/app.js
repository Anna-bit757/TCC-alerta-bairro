const express = require("express");
const cors = require("cors");
const path = require("path");
const authRoutes = require("./routes/authRoutes");
const reportRoutes = require("./routes/reportRoutes");
const userRoutes = require("./routes/userRoutes");

const app = express();
app.use(cors({ origin: process.env.FRONTEND_URL || "http://localhost:3000" }));
app.use(express.json({ limit: "1mb" }));
app.use("/uploads", express.static(path.join(__dirname, "../uploads"), {
  dotfiles: "deny",
  index: false,
  maxAge: "7d",
}));

app.get("/api/health", (_req, res) => res.json({ status: "ok", service: "alerta-bairro-api", timestamp: new Date().toISOString() }));
app.use("/api/auth", authRoutes);
app.use("/api/reports", reportRoutes);
app.use("/api/users", userRoutes);

app.use((req, res) => res.status(404).json({ message: "Rota não encontrada." }));
app.use((err, _req, res, _next) => {
  console.error(err);
  if (err.code === "ER_DUP_ENTRY") return res.status(409).json({ message: "Este e-mail já está cadastrado." });
  if (err.code === "LIMIT_FILE_SIZE") return res.status(400).json({ message: "Cada imagem pode ter no máximo 5 MB." });
  if (err.code === "LIMIT_FILE_COUNT" || err.code === "LIMIT_UNEXPECTED_FILE") return res.status(400).json({ message: "Envie no máximo 5 imagens por reclamação." });
  if (err.status === 400) return res.status(400).json({ message: err.message });
  const response = { message: "Erro interno da API." };
  if (process.env.NODE_ENV !== "production") {
    response.detail = err.message;
    response.code = err.code || null;
  }
  return res.status(500).json(response);
});

module.exports = app;
