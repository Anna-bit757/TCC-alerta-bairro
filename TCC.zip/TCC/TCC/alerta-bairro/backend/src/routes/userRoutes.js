const express = require("express");
const controller = require("../controllers/usersController");
const { authRequired } = require("../middleware/auth");
const router = express.Router();

router.use(authRequired);
router.patch("/me", controller.updateMe);

module.exports = router;
