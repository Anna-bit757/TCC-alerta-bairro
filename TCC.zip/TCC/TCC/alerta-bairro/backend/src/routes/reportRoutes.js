const express = require("express");
const controller = require("../controllers/reportsController");
const { authRequired } = require("../middleware/auth");
const { upload } = require("../middleware/upload");
const router = express.Router();

router.use(authRequired);
router.get("/", controller.list);
router.get("/stats", controller.stats);
router.post("/", upload.array("images", 5), controller.create);
router.patch("/:id/status", controller.updateStatus);
router.post("/:id/confirm", controller.confirm);

module.exports = router;
